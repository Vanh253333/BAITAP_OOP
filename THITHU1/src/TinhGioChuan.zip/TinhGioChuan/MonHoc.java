/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TinhGioChuan;

/**
 *
 * @author HP
 */
public class MonHoc {
    private String maMH, tenMH;

    public MonHoc(String maMH, String tenMH) {
        this.maMH = maMH;
        this.tenMH = tenMH;
    }
    
    public String getMaMh(){
        return maMH;
    }
}
